#!/bin/bash

# Check if Xcode Command Line Tools are installed
xcode-select --install

# Check if Homebrew is installed, install if we don't have it
if test ! $(which brew); then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
fi

# Update Homebrew
brew update

# Install git if it isn't installed
if test ! $(which git); then
    brew install git
fi

# Clone the repository
git clone https://github.com/oobabooga/text-generation-webui.git

# Navigate into the cloned repository
cd text-generation-webui

# Python3 is usually preinstalled on MacOS. Uncomment the next two lines if the project requires it
#python3 -m venv venv
#source venv/bin/activate

# Install dependencies
#pip install -r requirements.txt

# Compile the project
# This will depend on the specific build process for the project
# For instance, for a Python project, this might be running a setup.py script
#python setup.py install

# Run the server.py script
python3 server.py
## @Flames LLC 20XX [C] - AI RIGHTS RESERVED